hero: {
  eyebrow: "Available for acquisition",
  domain: "bogan.co.nz",
  headline: "A rare one-word NZ domain with cultural punch",
  subheadline:
    "bogan.co.nz is a memorable, commercially usable .co.nz domain with clear fit across apparel, automotive culture, media, events, merch, and humour-led NZ lifestyle branding.",
  supportingLine:
    "Premium one-word .co.nz domain. Serious acquisition enquiries invited.",
  primaryCta: {
    label: "Start an acquisition enquiry",
    href: "#enquire",
  },
  secondaryCta: {
    label: "See commercial directions",
    href: "#commercial-directions",
  },
},